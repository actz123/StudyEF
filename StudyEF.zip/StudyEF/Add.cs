﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyEF
{
    public partial class Add : Form
    {
        public Add()
        {
            InitializeComponent();
        }

        private void Add_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String username = textBox1.Text;
            String name = textBox2.Text;
            String password = textBox3.Text;
            String age = textBox4.Text;
            String phone = textBox5.Text;
            String email = textBox6.Text;
            String address = textBox7.Text;
            using (var study = new StudyEFEntities())
            {
                var test = new TestData // 假设TestData是您的实体类  
                {
                    // 在此处设置test对象的属性，例如：  
                    password = password,
                    username=username,
                    name=name,
                    age=age,
                    phone=phone,
                    email=email,
                    address=address
                };

                // 将test对象添加到数据库中  
                study.TestData.Add(test);
                // 保存更改到数据库  
                study.SaveChanges();
            }
            MessageBox.Show("添加成功");
            Main f1 = (Main)this.Owner;
            f1.Refresh_Method();
            f1.Activate();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

        }
    }
}
