﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyEF
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“studyEFDataSet2.checkname”中。您可以根据需要移动或删除它。
            this.checknameTableAdapter.Fill(this.studyEFDataSet2.checkname);
            // TODO: 这行代码将数据加载到表“studyEFDataSet1.TestData”中。您可以根据需要移动或删除它。
            this.testDataTableAdapter.Fill(this.studyEFDataSet1.TestData);

        }
        //添加按钮
        private void button1_Click(object sender, EventArgs e)
        {
            Add f1 = new Add();
            f1.Owner = this;
            f1.Show();
        }
        //刷新方法
        internal void Refresh_Method()
        {
            this.testDataTableAdapter.Fill(this.studyEFDataSet1.TestData);
        }
        //删除按钮
        private void button2_Click(object sender, EventArgs e)
        {
            var dev1 = this.dataGridView1.CurrentRow;
            using (var study = new StudyEFEntities())
            {
                if (dev1.Cells[0].Value != null)
                {
                    int idToDelete;
                    if (int.TryParse(dev1.Cells[0].Value.ToString(), out idToDelete))
                    {
                        var ToDelete = study.TestData.FirstOrDefault(u => u.id == idToDelete);
                        if (ToDelete != null)
                        {
                            study.TestData.Remove(ToDelete);
                            study.SaveChanges();
                        }
                    }
                }
                this.testDataTableAdapter.Fill(this.studyEFDataSet1.TestData);
            }
        }
        //修改按钮
        private void button3_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                var dev1 = this.dataGridView1.CurrentRow;
                Update frm = new Update(dev1);
                frm.Owner = this;
                frm.Show();
            }
            else
            {
                MessageBox.Show("请先选择一条数据");
            }
        }
        //查询按钮实现
        private void button4_Click(object sender, EventArgs e)
        {
            using (var study = new StudyEFEntities())
            {
                // 查询满足条件的用户 
                if (comboBox1.SelectedValue.ToString() == "u.id") 
                {
                    int ToCheck;
                    if (int.TryParse(textBox1.Text, out ToCheck))
                    {
                        var test = study.TestData.Where(u => u.id == ToCheck);
                        this.dataGridView1.DataSource = test.ToList(); 
                    }
                }
                if (comboBox1.SelectedValue.ToString() == "u.username")
                {
                    var test = study.TestData.Where(u => u.username == textBox1.Text);
                    this.dataGridView1.DataSource = test.ToList();
                }
                if (comboBox1.SelectedValue.ToString() == "u.name")
                {
                    var test = study.TestData.Where(u => u.name == textBox1.Text);
                    this.dataGridView1.DataSource = test.ToList();
                }
                if (comboBox1.SelectedValue.ToString() == "u.password")
                {
                    var test = study.TestData.Where(u => u.password == textBox1.Text);
                    this.dataGridView1.DataSource = test.ToList();
                }
                if (comboBox1.SelectedValue.ToString() == "u.phone")
                {
                    var test = study.TestData.Where(u => u.phone == textBox1.Text);
                    this.dataGridView1.DataSource = test.ToList();
                }
                if (comboBox1.SelectedValue.ToString() == "u.email")
                {
                    var test = study.TestData.Where(u => u.email == textBox1.Text);
                    this.dataGridView1.DataSource = test.ToList();
                }
                if (comboBox1.SelectedValue.ToString() == "u.phone")
                {
                    var test = study.TestData.Where(u => u.phone == textBox1.Text);
                    this.dataGridView1.DataSource = test.ToList();
                }

            }
        }
        //重置按钮实现
        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            comboBox1.Text = "";
            using (var study = new StudyEFEntities())
            {
                 
                var test = study.TestData;
                this.dataGridView1.DataSource = test.ToList();

            }
        }
    }
}
