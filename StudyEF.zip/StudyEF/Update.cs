﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyEF
{
    public partial class Update : Form
    {
        public Update(DataGridViewRow dev1)
        {
            InitializeComponent();
            textBox8.Text = dev1.Cells[0].Value.ToString();
            textBox1.Text = dev1.Cells[1].Value.ToString();
            textBox2.Text = dev1.Cells[2].Value.ToString();
            textBox3.Text = dev1.Cells[3].Value.ToString();
            textBox4.Text = dev1.Cells[4].Value.ToString();
            textBox5.Text = dev1.Cells[5].Value.ToString();
            textBox6.Text = dev1.Cells[6].Value.ToString();
            textBox7.Text = dev1.Cells[7].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = int.Parse(textBox8.Text);
            string username = textBox1.Text;
            string name = textBox2.Text;
            string password = textBox3.Text;
            string age = textBox4.Text;
            string phone = textBox5.Text;
            string email = textBox6.Text;
            string address = textBox7.Text;
            using (var study = new StudyEFEntities())
            {
                // 假设你要更新的是用户信息  
                var ToUpdate = study.TestData.FirstOrDefault(u => u.id == id);
                if (ToUpdate != null)
                {
                    // 更新用户的属性  
                    ToUpdate.username = username;
                    ToUpdate.name = name;
                    ToUpdate.password = password;
                    ToUpdate.age = age;
                    ToUpdate.phone = phone;
                    ToUpdate.email = email;
                    ToUpdate.address = address;
                    // 保存更改到数据库  
                    study.SaveChanges();
                }
            }
                MessageBox.Show("修改成功");
                Main f1 = (Main)this.Owner;
                f1.Refresh_Method();
                f1.Activate();
                this.Hide();
        }
    }
}
